<?php session_start();  
 session_destroy();
?>
<a href = "member-login.php">Login<a>