<?php session_start();  
 session_destroy();
?>
<a href = "admin-login.php">Login<a>